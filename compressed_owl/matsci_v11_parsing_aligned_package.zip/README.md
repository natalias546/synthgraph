# MatSci ontology v11 — parsing-aligned conservative enrichment

This release extends `matsci-v10-literature-materials-project-enriched.owl` without modifying `schemas.py`.

## Contents

- `ontology/matsci-v11-parsing-aligned-cleaned.owl`: complete enriched RDF/XML ontology, with only unreferenced explicitly-deprecated definitions removed.
- `ontology/matsci-extraction-application-extension.ttl`: Git-readable **additive vocabulary only**; import against original ontology if deletion of legacy definitions is undesirable.
- `ontology/matsci-v11-change-manifest.json`: class/property counts, SHA-256 checksums, every removed legacy IRI and every retained deprecated IRI with incoming-reference examples.
- `reports/ontology_to_schema_mapping_proposal.json`: proposed profile roots and relation mappings.
- `reports/schema_change_proposals.md`: recommendations; **not automatically applied**.
- `scripts/build_extension.py`: reproducible builder; requires `lxml` and `rdflib`.

## Place in your existing structure

```text
synthgraph/
├── ontology/
│   ├── matsci-v10-literature-materials-project-enriched.owl  # original, keep
│   ├── matsci-v11-parsing-aligned-cleaned.owl                 # new
│   └── matsci-extraction-application-extension.ttl           # new
├── src/
│   └── schemas.py    # unchanged
└── ...
```

## Loading

Protégé: open `matsci-v11-parsing-aligned-cleaned.owl`. It is RDF/XML and passed streaming XML parsing; full OWL reasoning was not executed.

Neo4j n10s: import the v11 full file with the RDF importer when all individuals are required. Ontology-only importer discards many instance facts. Large ~164 MB source: allocate sufficient Neo4j memory and import in batches if needed. Avoid mixing ontology-only and raw RDF import models in the same graph without a documented mapping.

## Semantics of application

New `MaterialsApplication` subclasses are **information content entities** capturing reported/intended uses, not assertion that a device has been built or a physical process has been realized. Existing classes `OpticalApplication` and `BiomedicalApplication` are subclasses of `COB_0000082` planned process, so they are cross-referenced (`rdfs:seeAlso`) instead of being incorrectly reparented under information content entities.

## Verification performed

- Complete cleaned file: streaming RDF/XML parsed.
- Standalone additive vocabulary: RDF/Turtle parsed with rdflib.
- No edit to `schemas.py`.

Not performed: full Protégé opening, OWL reasoner consistency check, Neo4j database import, external audit of public deprecated IRIs. The cleaned ontology should therefore be treated as a conservative migration candidate rather than a production cutover without review.
